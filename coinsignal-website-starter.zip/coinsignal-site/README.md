# CoinSignal website starter

A responsive, English-first static landing page for the CoinSignal crypto research concept.

## What's included
- `index.html` — responsive landing page with product positioning, feature overview, illustrative dashboard, and early-access section.
- No build step or paid dependency required.

## Important before publishing
- The dashboard values and token names are illustrative demo content, not live data.
- The early-access form is not connected to a database or email service. It only displays a local notice.
- Replace the X link with the official CoinSignal account once created.
- Add a real privacy policy and connect a form service (for example, a provider with a free tier) before collecting personal data.
- Review data provider licenses before displaying their data commercially.
- Do not market the activity indicators as proof that a token is safe or as a prediction of returns.

## Publish for free
### Cloudflare Pages
1. Create a GitHub repository and upload `index.html`.
2. In Cloudflare, open Workers & Pages and create a Pages project connected to the repository.
3. For a plain static HTML site, use no build command and set the output directory to the repository root (or follow the current Cloudflare Pages setup flow).
4. Deploy and test the generated URL on mobile and desktop.

### Netlify
1. Open Netlify and choose to deploy a static site.
2. Drag and drop the folder containing `index.html`, or connect your Git repository.
3. Test the site and configure a custom domain later if desired.

## Suggested next steps
1. Register the brand's social handles and a suitable domain if available.
2. Validate the landing page with 15–20 retail traders.
3. Connect a waitlist form.
4. Build a small live-data prototype for one blockchain/DEX ecosystem before expanding cross-chain.
